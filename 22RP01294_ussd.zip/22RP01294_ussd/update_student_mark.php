<?php
require 'db.php';
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $regno = trim($_POST['regno']);
    $module_id = (int)$_POST['module_id'];
    $mark = (int)$_POST['mark'];
    
    if (empty($regno) || empty($module_id) || $mark < 0 || $mark > 100) {
        $error = 'Please provide valid data (mark must be between 0-100)';
    } else {
        try {
            // Check if student exists
            $stmt = $pdo->prepare("SELECT id FROM students WHERE regno = ?");
            $stmt->execute([$regno]);
            
            if (!$stmt->fetch()) {
                $error = 'Student with this registration number not found';
            } else {
                // Check if module exists
                $stmt = $pdo->prepare("SELECT id FROM modules WHERE id = ?");
                $stmt->execute([$module_id]);
                
                if (!$stmt->fetch()) {
                    $error = 'Module not found';
                } else {
                    // Check if mark exists to update
                    $stmt = $pdo->prepare("SELECT id FROM marks WHERE student_regno = ? AND module_id = ?");
                    $stmt->execute([$regno, $module_id]);
                    $existing = $stmt->fetch();
                    
                    if (!$existing) {
                        $error = 'No existing mark found for this student and module (use insert instead)';
                    } else {
                        // Update the mark
                        $stmt = $pdo->prepare("UPDATE marks SET mark = ? WHERE student_regno = ? AND module_id = ?");
                        $stmt->execute([$mark, $regno, $module_id]);
                        $success = 'Mark successfully updated!';
                    }
                }
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Get all modules for dropdown
$modules = $pdo->query("SELECT id, module_name FROM modules ORDER BY module_name")->fetchAll();

// If coming from search with GET parameters
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['regno']) && isset($_GET['module_id'])) {
    $search_regno = trim($_GET['regno']);
    $search_module_id = (int)$_GET['module_id'];
    
    try {
        // Get existing mark - Fixed SQL syntax (changed 'mod' alias to 'mdl')
        $stmt = $pdo->prepare("SELECT m.mark, s.name, mdl.module_name 
                              FROM marks m
                              JOIN students s ON m.student_regno = s.regno
                              JOIN modules mdl ON m.module_id = mdl.id
                              WHERE m.student_regno = ? AND m.module_id = ?");
        $stmt->execute([$search_regno, $search_module_id]);
        $existing_mark = $stmt->fetch();
        
        if ($existing_mark) {
            $_POST['regno'] = $search_regno;
            $_POST['module_id'] = $search_module_id;
            $_POST['mark'] = $existing_mark['mark'];
        } else {
            $error = 'No existing mark found for the specified student and module';
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Student Marks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #34495e;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: none;
            margin-top: 30px;
        }
        
        .card-header {
            background-color: var(--secondary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .btn-update {
            background-color: var(--warning-color);
            border-color: var(--warning-color);
            padding: 10px 20px;
            font-weight: 500;
        }
        
        .btn-update:hover {
            background-color: #e0a800;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .search-card {
            margin-bottom: 20px;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        .alert {
            border-radius: 8px;
        }
        
        .student-info {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <!-- Search Form -->
                <div class="card search-card">
                    <div class="card-header">
                        <h4 class="mb-0"><i class="fas fa-search me-2"></i>Find Student Mark</h4>
                    </div>
                    <div class="card-body">
                        <form method="get" class="row g-3">
                            <div class="col-md-6">
                                <label for="search_regno" class="form-label">Registration Number</label>
                                <input type="text" class="form-control" id="search_regno" name="regno" 
                                       value="<?= htmlspecialchars($_GET['regno'] ?? '') ?>" 
                                       placeholder="Enter registration number" required>
                            </div>
                            <div class="col-md-6">
                                <label for="search_module_id" class="form-label">Module</label>
                                <select class="form-select" id="search_module_id" name="module_id" required>
                                    <option value="">Select Module</option>
                                    <?php foreach ($modules as $module): ?>
                                        <option value="<?= $module['id'] ?>" <?= isset($_GET['module_id']) && $_GET['module_id'] == $module['id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($module['module_name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search me-1"></i> Find Mark
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Update Form -->
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0"><i class="fas fa-edit me-2"></i>Update Student Mark</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                        <?php endif; ?>

                        <?php if (isset($existing_mark)): ?>
                        <div class="student-info">
                            <h5>Student Information</h5>
                            <p><strong>Name:</strong> <?= htmlspecialchars($existing_mark['name']) ?></p>
                            <p><strong>Module:</strong> <?= htmlspecialchars($existing_mark['module_name']) ?></p>
                            <p><strong>Current Mark:</strong> <?= htmlspecialchars($existing_mark['mark']) ?></p>
                        </div>
                        <?php endif; ?>
                        
                        <form method="post">
                            <div class="mb-3">
                                <label for="regno" class="form-label">Registration Number</label>
                                <input type="text" class="form-control" id="regno" name="regno" required
                                       value="<?= htmlspecialchars($_POST['regno'] ?? '') ?>" 
                                       placeholder="Enter registration number" <?= isset($_POST['regno']) ? 'readonly' : '' ?>>
                            </div>
                            
                            <div class="mb-3">
                                <label for="module_id" class="form-label">Module</label>
                                <select class="form-select" id="module_id" name="module_id" required <?= isset($_POST['module_id']) ? 'disabled' : '' ?>>
                                    <option value="">Select Module</option>
                                    <?php foreach ($modules as $module): ?>
                                        <option value="<?= $module['id'] ?>" <?= isset($_POST['module_id']) && $_POST['module_id'] == $module['id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($module['module_name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if (isset($_POST['module_id'])): ?>
                                <input type="hidden" name="module_id" value="<?= htmlspecialchars($_POST['module_id']) ?>">
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="mark" class="form-label">New Mark (0-100)</label>
                                <input type="number" class="form-control" id="mark" name="mark" 
                                       min="0" max="100" required
                                       value="<?= htmlspecialchars($_POST['mark'] ?? '') ?>"
                                       placeholder="Enter new mark">
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-update" <?= !isset($_POST['regno']) ? 'disabled' : '' ?>>
                                    <i class="fas fa-save me-1"></i> Update Mark
                                </button>
                                <a href="admin.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Client-side validation
        document.querySelector('form[method="post"]').addEventListener('submit', function(e) {
            const mark = document.getElementById('mark').value;
            if (mark < 0 || mark > 100) {
                alert('Mark must be between 0 and 100');
                e.preventDefault();
            }
        });

        // Enable/disable update button based on search
        const searchForm = document.querySelector('form[method="get"]');
        searchForm.addEventListener('submit', function() {
            setTimeout(() => {
                const updateBtn = document.querySelector('form[method="post"] button[type="submit"]');
                if (document.getElementById('regno').value && document.getElementById('module_id').value) {
                    updateBtn.disabled = false;
                }
            }, 100);
        });
    </script>
</body>
</html>