<?php
require 'db.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $regno = trim($_POST['regno']);
    $module_id = (int)$_POST['module_id'];
    $mark = (int)$_POST['mark'];
    
    // Validate inputs
    if (empty($regno) || empty($module_id) || $mark < 0 || $mark > 100) {
        $error = 'Please provide valid data (mark must be between 0-100)';
    } else {
        try {
            // Check if student exists
            $stmt = $pdo->prepare("SELECT id FROM students WHERE regno = ?");
            $stmt->execute([$regno]);
            $student = $stmt->fetch();
            
            if (!$student) {
                $error = 'Student with this registration number not found';
            } else {
                // Check if module exists
                $stmt = $pdo->prepare("SELECT id FROM modules WHERE id = ?");
                $stmt->execute([$module_id]);
                $module = $stmt->fetch();
                
                if (!$module) {
                    $error = 'Module not found';
                } else {
                    // Check if mark already exists
                    $stmt = $pdo->prepare("SELECT id FROM marks WHERE student_regno = ? AND module_id = ?");
                    $stmt->execute([$regno, $module_id]);
                    $existing = $stmt->fetch();
                    
                    if ($existing) {
                        $error = 'Mark for this student and module already exists (use update instead)';
                    } else {
                        // Insert new mark
                        $stmt = $pdo->prepare("INSERT INTO marks (student_regno, module_id, mark) VALUES (?, ?, ?)");
                        $stmt->execute([$regno, $module_id, $mark]);
                        $success = 'Mark successfully recorded!';
                    }
                }
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Get all modules for dropdown
$modules = $pdo->query("SELECT id, module_name FROM modules ORDER BY module_name")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Student Marks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --success-color: #2ecc71;
            --danger-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #34495e;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: none;
            margin-top: 30px;
        }
        
        .card-header {
            background-color: var(--secondary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .btn-submit {
            background-color: var(--success-color);
            border-color: var(--success-color);
            padding: 10px 20px;
            font-weight: 500;
        }
        
        .btn-submit:hover {
            background-color: #28a745;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        .alert {
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Insert Student Marks</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                        <?php endif; ?>
                        
                        <form method="post">
                            <div class="mb-3">
                                <label for="regno" class="form-label">Student Registration Number</label>
                                <input type="text" class="form-control" id="regno" name="regno" required 
                                       placeholder="Enter student registration number">
                            </div>
                            
                            <div class="mb-3">
                                <label for="module_id" class="form-label">Module</label>
                                <select class="form-select" id="module_id" name="module_id" required>
                                    <option value="">Select Module</option>
                                    <?php foreach ($modules as $module): ?>
                                        <option value="<?= $module['id'] ?>"><?= htmlspecialchars($module['module_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="mark" class="form-label">Mark (0-100)</label>
                                <input type="number" class="form-control" id="mark" name="mark" 
                                       min="0" max="100" required placeholder="Enter mark">
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-submit">
                                    <i class="fas fa-save me-1"></i> Save Mark
                                </button>
                                <a href="admin.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Simple client-side validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const mark = document.getElementById('mark').value;
            if (mark < 0 || mark > 100) {
                alert('Mark must be between 0 and 100');
                e.preventDefault();
            }
        });
    </script>
</body>
</html>