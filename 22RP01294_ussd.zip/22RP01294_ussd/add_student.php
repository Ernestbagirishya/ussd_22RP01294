<?php
require 'db.php';
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $regno = trim($_POST['regno']);
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    
    if (empty($regno) || empty($name) || empty($phone)) {
        $error = 'Please fill in all required fields';
    } elseif (!preg_match('/^[0-9]{10,15}$/', $phone)) {
        $error = 'Phone number must be 10-15 digits';
    } else {
        try {
            // Check if student exists in students table
            $stmt = $pdo->prepare("SELECT id FROM students WHERE regno = ?");
            $stmt->execute([$regno]);
            
            if ($stmt->fetch()) {
                $error = 'Student with this registration number already exists';
            } else {
                // Insert into students table
                $stmt = $pdo->prepare("INSERT INTO students (regno, name, phone_number) VALUES (?, ?, ?)");
                $stmt->execute([$regno, $name, $phone]);
                $success = 'Student successfully added!';
                $_POST = array(); // Clear form
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ... (keep the same styles as before) ... */
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0"><i class="fas fa-user-plus me-2"></i>Add New Student</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                        <?php endif; ?>
                        
                        <form method="post">
                            <div class="mb-3">
                                <label for="regno" class="form-label required">Registration Number</label>
                                <input type="text" class="form-control" id="regno" name="regno" required
                                       value="<?= htmlspecialchars($_POST['regno'] ?? '') ?>" 
                                       placeholder="e.g. ABC123">
                            </div>
                            
                            <div class="mb-3">
                                <label for="name" class="form-label required">Full Name</label>
                                <input type="text" class="form-control" id="name" name="name" required
                                       value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                                       placeholder="e.g. John Doe">
                            </div>
                            
                            <div class="mb-3">
                                <label for="phone" class="form-label required">Phone Number</label>
                                <input type="tel" class="form-control" id="phone" name="phone" required
                                       value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"
                                       placeholder="e.g. 254712345678">
                                <small class="text-muted">Format: 10-15 digits only</small>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-save me-1"></i> Add Student
                                </button>
                                <a href="admin.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelector('form').addEventListener('submit', function(e) {
            const phone = document.getElementById('phone').value;
            if (!/^[0-9]{10,15}$/.test(phone)) {
                alert('Phone number must be 10-15 digits only');
                e.preventDefault();
            }
        });
    </script>
</body>
</html>