<?php
require 'db.php';
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

// Setup pagination and filters
$perPage = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$startAt = ($page - 1) * $perPage;

$statusFilter = $_GET['status'] ?? '';
$searchRegno = $_GET['search'] ?? '';

$params = [];
$where = "WHERE 1";

if ($statusFilter && in_array($statusFilter, ['pending', 'under review', 'resolved'])) {
    $where .= " AND a.status = ?";
    $params[] = $statusFilter;
}

if ($searchRegno) {
    $where .= " AND s.regno LIKE ?";
    $params[] = "%$searchRegno%";
}

// Get appeals data
$sql = "SELECT a.id, s.name AS student_name, s.regno, m.module_name, a.reason, a.status, mk.mark
        FROM appeals a 
        JOIN students s ON a.student_regno = s.regno 
        JOIN modules m ON a.module_id = m.id 
        LEFT JOIN marks mk ON mk.student_regno = s.regno AND mk.module_id = m.id
        $where
        LIMIT $startAt, $perPage";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$appeals = $stmt->fetchAll();

// Total count for pagination
$countStmt = $pdo->prepare("SELECT COUNT(*) 
                            FROM appeals a 
                            JOIN students s ON a.student_regno = s.regno 
                            $where");
$countStmt->execute($params);
$totalAppeals = $countStmt->fetchColumn();
$totalPages = ceil($totalAppeals / $perPage);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Appeals Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #34495e;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: none;
            margin-bottom: 20px;
        }
        
        .card-header {
            background-color: var(--secondary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
        }
        
        .status-pending {
            color: var(--warning-color);
            font-weight: 600;
        }
        
        .status-under-review {
            color: var(--primary-color);
            font-weight: 600;
        }
        
        .status-resolved {
            color: var(--success-color);
            font-weight: 600;
        }
        
        .table-responsive {
            border-radius: 8px;
            overflow: hidden;
        }
        
        .table th {
            background-color: var(--secondary-color);
            color: white;
            font-weight: 500;
        }
        
        .table td {
            vertical-align: middle;
        }
        
        .action-form {
            display: flex;
            gap: 8px;
        }
        
        .form-select {
            min-width: 150px;
        }
        
        .pagination .page-item.active .page-link {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }
        
        .pagination .page-link {
            color: var(--secondary-color);
        }
        
        .search-box {
            position: relative;
        }
        
        .search-box i {
            position: absolute;
            top: 50%;
            left: 12px;
            transform: translateY(-50%);
            color: #6c757d;
        }
        
        .search-box input {
            padding-left: 35px;
        }
        
        .welcome-text {
            font-size: 1.1rem;
            color: var(--light-color);
        }
        
        .logout-btn {
            transition: all 0.3s;
        }
        
        .logout-btn:hover {
            transform: translateY(-2px);
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .btn-insert {
            background-color: var(--success-color);
            border-color: var(--success-color);
        }
        
        .btn-update {
            background-color: var(--warning-color);
            border-color: var(--warning-color);
        }
        
        .btn-view {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-action {
            color: white;
            transition: all 0.3s;
            padding: 10px 15px;
            font-weight: 500;
        }
        
        .btn-action:hover {
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .btn-action i {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-graduation-cap me-2"></i>Appeals Management
            </a>
            <div class="d-flex align-items-center">
                <span class="welcome-text me-3">Welcome, <?= htmlspecialchars($_SESSION['admin']) ?></span>
                <a href="logout.php" class="btn btn-danger logout-btn">
                    <i class="fas fa-sign-out-alt me-1"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- Action Buttons -->
        <div class="action-buttons">
            <a href="add_student.php" class="btn btn-insert btn-action">
                <i class="fas fa-plus-circle"></i> Insert Student 
            </a>
            <a href="insert_student_marks.php" class="btn btn-insert btn-action">
                <i class="fas fa-plus-circle"></i> Insert Student Marks
            </a>
            <a href="update_student_mark.php" class="btn btn-update btn-action">
                <i class="fas fa-edit"></i> Update Student Marks
            </a>
        </div>

        <!-- Filter Card -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filter Appeals</h5>
            </div>
            <div class="card-body">
                <form method="get" class="row g-3">
                    <div class="col-md-6 search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" class="form-control" name="search" placeholder="Search by Registration Number" value="<?= htmlspecialchars($searchRegno) ?>">
                    </div>
                    <div class="col-md-4">
                        <select name="status" class="form-select">
                            <option value="">All Statuses</option>
                            <option value="pending" <?= $statusFilter == 'pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="under review" <?= $statusFilter == 'under review' ? 'selected' : '' ?>>Under Review</option>
                            <option value="resolved" <?= $statusFilter == 'resolved' ? 'selected' : '' ?>>Resolved</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-1"></i> Apply
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Appeals Table -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Student Appeals</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Student</th>
                                <th>Module</th>
                                <th>Marks</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($appeals)): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4">No appeals found</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($appeals as $i => $a): ?>
                                <tr>
                                    <td><?= $i+1 + $startAt ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($a['student_name']) ?></strong>
                                        <div class="text-muted small"><?= $a['regno'] ?></div>
                                    </td>
                                    <td><?= htmlspecialchars($a['module_name']) ?></td>
                                    <td>
                                        <span class="badge bg-<?= is_numeric($a['mark']) ? 'primary' : 'secondary' ?>">
                                            <?= is_numeric($a['mark']) ? $a['mark'] : 'N/A' ?>
                                        </span>
                                    </td>
                                    <td><?= htmlspecialchars($a['reason']) ?></td>
                                    <td>
                                        <span class="status-<?= str_replace(' ', '-', $a['status']) ?>">
                                            <?= ucfirst($a['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <form method="post" action="update_status.php" class="action-form">
                                            <input type="hidden" name="id" value="<?= $a['id'] ?>">
                                            <select name="status" class="form-select form-select-sm">
                                                <option value="pending" <?= $a['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                                                <option value="under review" <?= $a['status'] == 'under review' ? 'selected' : '' ?>>Under Review</option>
                                                <option value="resolved" <?= $a['status'] == 'resolved' ? 'selected' : '' ?>>Resolved</option>
                                            </select>
                                            <button type="submit" class="btn btn-sm btn-success">
                                                <i class="fas fa-save"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&status=<?= urlencode($statusFilter) ?>&search=<?= urlencode($searchRegno) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>